# Biplanar Lumbar Reconstruction — Interactive Demo

An interactive companion to *Synthetic supervision enables 3D lumbar reconstruction from biplanar radiographs for personalized surgical planning*.

This static site presents numbered precomputed cases, each including original AP and lateral radiographs, extracted vertebral images, reconstructed L1–L5 surfaces, CT registration reference surfaces and imaging geometry. It does not run network inference in the browser.

## Research framework

The manuscript describes two complementary stages:

1. **Domain-adapted vertebra extraction.** An HRNet-based extraction network is trained using labeled CT-generated digitally reconstructed radiographs (DRRs) and unlabeled real radiographs. Domain-adversarial training encourages shared features and isolates vertebral images from overlapping anatomy.
2. **Synthetically supervised surface reconstruction.** A template neural localization field is trained using statistical shape model sampling, local deformations and randomized projections. Dual-view image features, fixed template spectral encodings, geometric triangulation and 3D compensation predict template-corresponding surface vertices in the imaging coordinate system.

Template correspondence supports transfer of predefined anatomical features. The manuscript evaluates reconstruction against CT-derived surfaces registered into the biplanar imaging coordinate system and investigates pedicle screw guides and personalized spinal rods in simulated procedures.

## Local preview

From the repository root (`github_ready`), run:

```sh
python demo/serve_demo.py
```

Open `http://127.0.0.1:8765/demo/` in a modern browser with WebGL 2 support. Keep the terminal process running while using the page. Use an HTTP server rather than opening the HTML directly through `file://`, which prevents loading modules and case assets.

## Controls

Use the **Case library** selector or previous/next buttons to switch between **numbered cases**. Images, reconstruction surfaces and CT references load together for the selected case. Interface labels and asset URLs use only case numbers.

- Select the four workflow steps to inspect biplanar input, vertebra extraction, 3D reconstruction and reference comparison.
- Select **AP view**, **Lateral view** or an image card to inspect surface projections against the corresponding image.
- Switch between **Original** and **Extracted** to update the image cards and projection background.
- Enable or hide the reconstruction, image overlay and CT reference independently. Adjust their opacity and choose a wireframe or surface representation.
- Select **Free 3D** to orbit the vertebrae together with both images. The image meshes occupy the supplied detector corner coordinates in the same spatial frame as the surfaces; their relative poses remain fixed while the camera orbits. **Show images** hides or shows both planes, and **Image opacity** adjusts their visibility. Drag to orbit, scroll to zoom and right-drag to pan; use one or two fingers on touch screens. **Original / Extracted** updates both planes.
- Click an L1–L5 button to toggle that level; double-click to isolate it. **All** restores every level.
- Use **Reset view** to restore the current camera.

Reconstruction and CT reference retain their supplied spatial coordinates without additional rigid alignment.

## GitHub Pages

The current web release may also be supplied as `demo-site.zip` in the repository root. The workflow unpacks that numbered-asset bundle into `demo/` before validation and publishing. Both the source-directory and bundle layouts are supported.

Use the existing public repository: [ywx0314/lumbar-reconstruction](https://github.com/ywx0314/lumbar-reconstruction).

Upload or commit only these website files, preserving their paths relative to the repository root:

```text
.github/workflows/demo-pages.yml
demo/index.html
demo/README.md
demo/web/                     (include all numbered assets and vendor files)
```

The local source-image folders, source meshes, `projectMetrics/`, manuscript and preview scripts are not required for hosting. The numbered assets under `demo/web/cases/` are ready to serve.

1. Commit and push the files listed above to the existing repository on `main` or `master`.
2. In **Settings → Pages → Build and deployment → Source**, select **GitHub Actions**.
3. Run **Actions → Deploy reconstruction demo → Run workflow** for the first deployment. Later changes under `demo/` trigger automatic deployment.
4. After the workflow succeeds, visit [https://ywx0314.github.io/lumbar-reconstruction/](https://ywx0314.github.io/lumbar-reconstruction/). Use the exact URL shown by the deployment if GitHub reports a different address.

The workflow stages only `index.html`, this guide and the `web/` directory, which contains numbered browser assets. Original folders with identifying filenames, source NPZ files and manuscript documents are excluded from the Pages artifact. All asset paths are relative, so the site also supports deployment under a URL subdirectory. The Pages workflow publishes the website after the listed files are committed and pushed.

The site is static: GitHub Pages serves the page, images and meshes, and the browser renders the interactive viewer. No Python server is needed on GitHub Pages. See the [official GitHub Pages workflow guide](https://docs.github.com/en/pages/getting-started-with-github-pages/using-custom-workflows-with-github-pages).

## Links

- [Orthopaedic Biomechanics Lab](https://obl.sjtu.edu.cn/tsai.html)
- [Public project repository](https://github.com/ywx0314/lumbar-reconstruction)

## Data preparation and verification

After adding or replacing local case inputs, regenerate the numbered browser assets (requires NumPy and Pillow):

```sh
python demo/prepare_demo.py
```

The script matches paired images, five reconstruction meshes, five reference meshes and the case parameter file. It handles a unique mesh-folder match when an image identifier has a trailing numeric suffix. It exports only numbered case folders, re-encodes decoded image pixels without EXIF/comments, and replaces binary STL headers with generic text. The original local files remain untouched. Case numbering follows the sorted local input identifiers; regenerate the entire library after changing inputs.

To verify every case (requires Node.js; no npm installation):

```sh
node demo/web/geometry.test.js
```

The check traverses all reconstruction/reference triangle vertices in both views and compares matrix projection with the reconstruction code's ray–detector intersection algorithm.

## Loading behavior

The case list loads independently of the 3D module. The viewer loads only the selected case, with four concurrent surface requests, per-request timeouts and progress updates. The local preview helper serves through a threaded server without per-request console output and revalidates files to avoid stale application scripts. Keep it running while using the demo.

## Files and dependencies

The application consists of `index.html`, `web/style.css`, `web/app.js` and `web/geometry.js`. The browser reads numbered exports under `web/cases/` using `web/data/cases.json`. Source images, meshes and NPZ files remain unchanged in the local input folders.

Three.js, OrbitControls and STLLoader are bundled locally at version **0.170.0**, so no external CDN, build step or inference server is required. Their MIT license is included in `web/vendor/THREE-LICENSE.txt`. Project-owned code follows the repository research-only license.

# Lumbar reconstruction research demo

The page includes the reconstruction viewer, point correspondence and citation and is an interactive companion to *Synthetic supervision enables 3D lumbar reconstruction from biplanar radiographs for personalized surgical planning* (Wanxin Yu et al., unpublished manuscript, 2026).

## Preview

From the extracted project folder, double-click `Preview.cmd` on Windows, or run:

    node demo/serve-demo.mjs

Then open http://127.0.0.1:8765/demo/ and keep the preview window open. Python is an alternative:

    python demo/serve_demo.py

The website is static, with bundled Three.js dependencies. No package installation or build is required. Use HTTP rather than opening `index.html` directly.

## What is shown

- Five selected reconstruction examples, numbered Case 001–005, each with AP/lateral radiographs, extracted vertebral images, L1–L5 reconstruction surfaces, CT registration reference surfaces and calibrated geometry.
- A separate Case 000 containing the supplied L1–L5 SSM reference meshes. It has no patient images or cameras and appears only in Point mapping.
- A provisional citation with a copy button. After the point mapping workspace, Citation is the only remaining content section.

Model inference is performed offline. CT-derived references are registered to the imaging frame; they should not be interpreted as error-free ground truth. The guide and rod workflows were studied on printed models, and require further cadaveric and clinical validation.

## Point correspondence and internal interpolation

**Case 000 · SSM template** uses the user-supplied `2000L1.stl` through `2000L5.stl`, stored under `web/templates/ssm/recons/`. The supplied MAT vertex arrays and common face indices agree exactly with the STL meshes after float32 conversion. Geometry and index order are preserved; only the STL text headers were generalized. Source and asset hashes are recorded in `web/templates/ssm/template.json`. PCA basis data are not exposed as a shape editor in this demo.

The **Point mapping** section pairs one L1–L5 level from Case 000 with any of the five target reconstructions. Click the source mesh to add a point; up to six colored points are retained. Switch target cases to preserve those source coordinates and map them onto the new boundary. Camera motion is linked. Rendered meshes are recentered independently for inspection. The source is also rotated by a fixed −90° about X to bridge the template and imaging axis conventions. Picking converts world intersections back to native source coordinates; readouts and mapping calculations retain their original mesh coordinates in millimeters. This display rotation is separate from case selection, which uses the unchanged supplied imaging frames. Each template level has its own native local frame, so the templates are inspected one level at a time.

- **Surface point:** retains the source triangle index and barycentric weights. This extends the common indexed boundary to arbitrary points on its triangles.
- **Interior point:** uses 3D mean value coordinates (Ju, Schaefer and Warren, 2005) with an exact boundary branch. Click the source mesh and adjust depth between the first solid entry/exit pair. Mesh winding checks exclude the vertebral foramen and reject external source queries.
- **Interior cloud:** samples a small deterministic lattice inside the source and retains the same weights when switching target cases. Lower shell opacity to inspect the mapped points.

All twenty-five selected reconstruction meshes and the five supplied templates have 2,000 vertices and 4,000 triangles, with matching indexed connectivity for each lumbar level. CT reference meshes do not have this topology and are excluded from point transfer.

The manuscript validates anatomical feature transfer on reconstructed surfaces (Figure 6). The interior interpolation is an added geometric demonstration, not a reproduction of an undocumented internal neural-field query. Mean value weights can be negative in nonconvex anatomy. The method does not guarantee a bijection or keep every mapped query inside the target; the UI reports external mapped samples. The numerical residual checks reproduction of the source coordinate, not clinical anatomical accuracy.

Run the numerical and real-mesh checks:

    node demo/web/correspondence.test.js

The test covers matching topology, vertex/triangle boundaries, interior identity and affine precision, negative weights, external queries, and the vertebral foramen. Independently calculated numerical errors are not clinical registration or landmark errors.

## Viewer

The initial view shows solid reconstructed surfaces in Free 3D. Workflow steps apply consistent presets:

1. **Biplanar input:** original images, with surfaces hidden.
2. **Vertebra extraction:** extracted images, with surfaces hidden.
3. **3D reconstruction:** Free 3D, full surface opacity, images and reference hidden.
4. **Reference comparison:** AP projection with original image, 65% surface opacity and CT reference overlay.

Use AP/Lateral view or an image card for calibrated projection overlays. In Free 3D, drag to orbit, scroll to zoom and right-drag to pan. On touch screens, use one finger to orbit and two fingers to zoom or pan. Optional auto-rotation stops when switching to a projection view.

Original/Extracted changes both image previews and image planes. Show images and image opacity control both fixed detector planes in Free 3D. Their spatial relationship to the surfaces remains fixed while orbiting. Click a lumbar level to toggle it, double-click to isolate it, or use Show all. Reconstruction and reference retain their supplied imaging coordinates without additional rigid alignment.

The viewer loads only the selected case, with progress reporting, request timeouts and recoverable case loading. Rendering pauses when hidden or outside the visible area. Static image previews and the citation remain readable if WebGL cannot start.

## Case selection

All twelve original demo cases were screened against their supplied CT registration references in the native imaging frame, including the case previously used as a temporary template. No additional registration, scaling or ICP was applied. For each lumbar level, deterministic area-weighted samples on each source surface are measured against the continuous target triangles. The two directional means are averaged to estimate ASSD; the case score is the equal mean across L1–L5. The five lowest scores are retained and numbered in rank order. Area integration is refined for the top six to check the selection boundary.

This is a curated demonstration subset, not an unbiased estimate of cohort performance or a rerun of the manuscript's original evaluation. Sampled Hausdorff values in the audit are lower approximations to continuous HD. The complete ranking, level scores, convergence checks, input hashes and reproducible calculation are supplied in the editable package's `case-selection/` folder. Unselected patient assets are removed from the demo; the original full set is preserved separately in the pre-edit backup.

## Editing and verification

- `index.html`: page structure and English research content.
- `web/style.css`: visual design and responsive layout.
- `web/site.js`: citation copying, independent of WebGL.
- `web/mapping-viewer.js`: linked source/target views, selection, point clouds and coordinate readouts.
- `web/correspondence.js`: indexed topology checks, barycentric and mean value coordinates.
- `web/correspondence.test.js`: numerical and real-mesh verification.
- `web/bootstrap.js`: case library and viewer startup.
- `web/app.js`: interactive viewer and display presets.
- `web/geometry.js`: calibrated projection and detector plane geometry.
- `web/assets/research-overview.webp`: supplied manuscript Figure 1.
- `web/data/cases.json` and `web/cases/`: anonymous numbered browser assets.
- `web/templates/ssm/`: supplied SSM meshes and source hashes.

Update cache query strings in `index.html` and `bootstrap.js` when editing CSS or JavaScript. Run the existing geometric verification from the project root:

    node demo/web/geometry.test.js

## Updating the existing GitHub Pages deployment

The existing public repository is https://github.com/ywx0314/lumbar-reconstruction . This local editing task does not push or deploy changes.

The repository workflow supports a root-level `demo-site.zip`, which takes precedence over the committed `demo/` directory. Replace that bundle with the regenerated archive supplied alongside this project, and use the updated `.github/workflows/demo-pages.yml`. This workflow extracts the complete bundle into a clean staging directory before replacing `demo/`, so removed cases cannot survive as stale files from an older checkout. Its root contains `index.html`, `README.md` and `web/`; there must be no enclosing `demo/` directory in the ZIP. Alternatively remove the older bundle when switching to directory-based deployment.

Keep LICENSE, CITATION.md and THIRD_PARTY_NOTICES.md with redistributed project copies. The bundled Three.js license is in `web/vendor/THREE-LICENSE.txt`. The research overview figure comes from the supplied manuscript; the public references informed page structure and no images or code were copied from them.

## Page trim

At the user's request, all page content from “How the point transfer works” onward was removed except Citation. This includes the explanation accordion, Figure 6, method, results, application galleries, resource introduction and footer. The preceding reconstruction and point mapping controls remain. Source figure assets are retained locally but are no longer linked or displayed on the page.


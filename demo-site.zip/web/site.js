// Page interactions stay independent of the WebGL viewer.
const copyButton = document.getElementById('copy-citation');
const copyStatus = document.getElementById('copy-status');
let resetCopy;
copyButton.addEventListener('click', async () => {
  try {
    await navigator.clipboard.writeText(document.getElementById('citation-text').textContent.trim());
    copyButton.textContent = 'Copied ✓';
    copyStatus.textContent = 'Citation copied to clipboard.';
    clearTimeout(resetCopy);
    resetCopy = setTimeout(() => { copyButton.textContent = 'Copy citation ⧉'; }, 2400);
  } catch {
    copyStatus.textContent = 'Select and copy the citation text below.';
    copyButton.textContent = 'Select text below';
  }
});

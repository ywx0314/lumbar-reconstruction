import * as THREE from 'three';
import { OrbitControls } from './vendor/OrbitControls.js';
import { STLLoader } from './vendor/STLLoader.js';
import { calibratedProjection, detectorPlaneData } from './geometry.js?v=planes-1';

const $=id=>document.getElementById(id);
const state={view:'AP',source:'raw',stage:'compare',levels:new Set([1,2,3,4,5]),ready:false};
let caseList=[],currentCase=null,caseLoading=false;
const colors=[0x43d9b1,0x63a9ff,0xb294f5,0xf2cc60,0xf080b8];
const root=new URL('../',import.meta.url);
const scene=new THREE.Scene();
const renderer=new THREE.WebGLRenderer({antialias:true,alpha:true,preserveDrawingBuffer:false});
renderer.setPixelRatio(Math.min(window.devicePixelRatio,2));
renderer.setClearColor(0x101c24,0);
renderer.outputColorSpace=THREE.SRGBColorSpace;
$('canvas-host').appendChild(renderer.domElement);
renderer.domElement.setAttribute('aria-label','Interactive 3D lumbar surface viewer');
renderer.domElement.setAttribute('role','img');
const freeCamera=new THREE.PerspectiveCamera(38,1,1,10000);
freeCamera.up.set(0,1,0);
const fixedCamera=new THREE.PerspectiveCamera();
let camera=fixedCamera, cameras;
const controls=new OrbitControls(freeCamera,renderer.domElement);
controls.enableDamping=true;controls.enabled=false;controls.minDistance=80;controls.maxDistance=1800;
scene.add(new THREE.HemisphereLight(0xe9faff,0x36444c,2));
const light=new THREE.DirectionalLight(0xffffff,2.4);light.position.set(150,280,650);scene.add(light);
const fill=new THREE.DirectionalLight(0x9bc9ff,1.6);fill.position.set(-450,60,-250);scene.add(fill);
const predicted=new THREE.Group(),reference=new THREE.Group();scene.add(predicted,reference);
const imagePlanes=new THREE.Group();scene.add(imagePlanes);
let caseTextures={};
const bounds=new THREE.Box3(),center=new THREE.Vector3();
let radius=120;

function caseAsset(path,entry=currentCase){return new URL(entry.base+path,root).href;}
function imagePath(view){return caseAsset(`${state.source}/${view}.png`);}
function refreshImages(){
  for(const v of ['AP','ML']){$(`thumb${v}`).src=imagePath(v);$(`thumb${v}`).alt=`${v} ${state.source==='raw'?'original radiograph':'extracted vertebral image'}`;}
  if(state.view!=='free'){$('backdrop').src=imagePath(state.view);$('backdrop').alt=`${state.view} ${state.source==='raw'?'original radiograph':'extracted vertebral image'} projection background`;}
  document.querySelectorAll('[data-source]').forEach(b=>{b.classList.toggle('active',b.dataset.source===state.source);b.setAttribute('aria-pressed',b.dataset.source===state.source);});
  for(const mesh of imagePlanes.children)if(mesh.isMesh){mesh.material.map=caseTextures[`${state.source}-${mesh.userData.view}`];mesh.material.needsUpdate=true;}
}
function updateLayers(){
  const free=state.view==='free';
  $('backdrop').hidden=free||!$('show-image').checked;
  $('backdrop').style.opacity=$('image-opacity').value/100;
  imagePlanes.visible=free&&$('show-image').checked&&!caseLoading;
  $('plane-legend').hidden=!imagePlanes.visible;
  for(const object of imagePlanes.children)object.material.opacity=object.isMesh?$('image-opacity').value/100:Math.min(1,$('image-opacity').value/100+.2);
  for(const [id,label] of [['model-opacity','model-opacity-value'],['image-opacity','image-opacity-value'],['gt-opacity','gt-opacity-value']]) $(label).value=`${$(id).value}%`;
  const wire=$('wireframe').checked,gtWire=$('gt-style').value==='wire';
  predicted.children.forEach(m=>{m.visible=$('show-model').checked&&state.levels.has(m.userData.level);m.material.opacity=$('model-opacity').value/100;m.material.wireframe=wire;m.material.depthWrite=m.material.opacity===1;});
  reference.children.forEach(m=>{m.visible=$('show-gt').checked&&state.levels.has(m.userData.level);m.material.opacity=$('gt-opacity').value/100;m.material.wireframe=gtWire;m.material.depthWrite=m.material.opacity===1;});
  $('gt-legend').hidden=!$('show-gt').checked;
  document.querySelector('.viewer-legend .pred-dot').parentElement.hidden=!$('show-model').checked;
  document.querySelectorAll('.level-button').forEach(b=>{b.classList.toggle('active',state.levels.has(+b.dataset.level));b.setAttribute('aria-pressed',state.levels.has(+b.dataset.level));});
}
function resetFree(preserveDirection=false){
  const direction=preserveDirection?freeCamera.position.clone().sub(controls.target).normalize():new THREE.Vector3(1.1,.55,1.4).normalize();
  const framing=bounds.clone();
  if($('show-image').checked)framing.union(new THREE.Box3().setFromObject(imagePlanes));
  const target=framing.getCenter(new THREE.Vector3());
  const framingRadius=framing.getSize(new THREE.Vector3()).length()/2;
  const distance=framingRadius/Math.sin(THREE.MathUtils.degToRad(freeCamera.fov/2))*1.06;
  controls.target.copy(target);freeCamera.position.copy(target).add(direction.multiplyScalar(distance));
  freeCamera.lookAt(target);controls.update();
}
function setView(view,{reset=false}={}){
  state.view=view;
  if(view==='free'){
    camera=freeCamera;controls.enabled=true;
    if(reset)resetFree();
  }else{
    camera=fixedCamera;controls.enabled=false;
    camera.position.fromArray(cameras[view].source);camera.quaternion.identity();camera.scale.set(1,1,1);
    camera.updateMatrixWorld(true);
    camera.projectionMatrix.set(...calibratedProjection(cameras[view],1,10000,true));
    camera.projectionMatrixInverse.copy(camera.projectionMatrix).invert();
    $('show-image').checked=true;
  }
  document.querySelectorAll('[data-view]').forEach(b=>{b.classList.toggle('active',b.dataset.view===view);b.setAttribute('aria-pressed',b.dataset.view===view);});
  $('view-name').textContent=view==='free'?'3D · Free exploration':`${view==='ML'?'Lateral':view} · Projection overlay`;
  $('interaction-hint').textContent=view==='free'?'Drag to orbit · Images stay at their projection positions · Scroll to zoom':'Projection view locked. Switch to Free 3D to rotate.';
  $('orientation').hidden=view==='free';
  refreshImages();updateLayers();
}
function setSource(source){state.source=source;refreshImages();updateLayers();}
const descriptions={raw:'Input: anteroposterior and lateral radiographs from the same case provide complementary projection information.',seg:'Extraction: precomputed outputs of the domain-adapted vertebra extraction network isolate lumbar anatomy from overlapping tissues.',recons:'Reconstruction: the template neural localization field predicts L1–L5 surfaces with anatomical correspondence. Rotate to inspect vertebral morphology and spatial alignment.',compare:'Inspect surface projections against the original radiographs, or overlay the CT registration reference to compare vertebral shape and position.'};
function setStage(stage){
  state.stage=stage;
  document.querySelectorAll('[data-stage]').forEach(b=>{b.classList.toggle('active',b.dataset.stage===stage);b.setAttribute('aria-pressed',b.dataset.stage===stage);});
  $('stage-description').textContent=descriptions[stage];
  $('show-model').checked=stage==='recons'||stage==='compare';
  $('show-gt').checked=stage==='compare';
  if(stage==='raw'||stage==='seg'){setSource(stage);setView(state.view==='free'?'AP':state.view);}
  else if(stage==='recons'){setView('free',{reset:true});$('model-opacity').value=100;}
  else{setSource('raw');$('model-opacity').value=65;setView('AP');}
  updateLayers();
}
for(let i=1;i<=5;i++){
  const b=document.createElement('button');b.className='level-button active';b.textContent=`L${i}`;b.dataset.level=i;b.title=`L${i}: click to toggle, double-click to isolate`;b.style.setProperty('--level-color',`#${colors[i-1].toString(16)}`);
  b.onclick=()=>{state.levels.has(i)?state.levels.delete(i):state.levels.add(i);updateLayers();};
  b.ondblclick=()=>{state.levels=new Set([i]);updateLayers();};$('levels').appendChild(b);
}
const actionButtons=[...document.querySelectorAll('button')];actionButtons.forEach(b=>b.disabled=true);
const actionInputs=[...document.querySelectorAll('input,select')];actionInputs.forEach(el=>el.disabled=true);
document.querySelectorAll('[data-view]').forEach(b=>b.onclick=()=>setView(b.dataset.view,{reset:b.dataset.view==='free'&&state.view!=='free'}));
document.querySelectorAll('[data-source]').forEach(b=>b.onclick=()=>setSource(b.dataset.source));
document.querySelectorAll('[data-stage]').forEach(b=>b.onclick=()=>setStage(b.dataset.stage));
document.querySelectorAll('input,select').forEach(el=>el.addEventListener('input',()=>{
  if(el.id==='case-select')return;
  updateLayers();
  if(el.id==='show-image'&&state.view==='free')resetFree(true);
}));
$('all-levels').onclick=()=>{state.levels=new Set([1,2,3,4,5]);updateLayers();};
$('reset').onclick=()=>setView(state.view,{reset:true});
function smoothNormals(geometry){
  geometry.computeVertexNormals();
  const pos=geometry.attributes.position,normals=geometry.attributes.normal,map=new Map();
  const key=i=>`${pos.getX(i).toFixed(4)},${pos.getY(i).toFixed(4)},${pos.getZ(i).toFixed(4)}`;
  for(let i=0;i<pos.count;i++){const k=key(i),v=map.get(k)||new THREE.Vector3();v.add(new THREE.Vector3().fromBufferAttribute(normals,i));map.set(k,v);}
  for(const v of map.values())v.normalize();
  for(let i=0;i<pos.count;i++){const v=map.get(key(i));normals.setXYZ(i,v.x,v.y,v.z);}normals.needsUpdate=true;
}
function disposeMeshes(meshes){for(const mesh of meshes){mesh.removeFromParent();mesh.geometry.dispose();mesh.material.dispose();}}
function makeImagePlanes(nextCameras,textures){
  const objects=[];
  for(const view of ['AP','ML']){
    const {positions,uvs,indices}=detectorPlaneData(nextCameras[view]);
    const geometry=new THREE.BufferGeometry();
    geometry.setAttribute('position',new THREE.Float32BufferAttribute(positions,3));
    geometry.setAttribute('uv',new THREE.Float32BufferAttribute(uvs,2));geometry.setIndex(indices);geometry.computeVertexNormals();
    const material=new THREE.MeshBasicMaterial({map:textures[`${state.source}-${view}`],side:THREE.DoubleSide,transparent:true,depthWrite:false,toneMapped:false});
    const mesh=new THREE.Mesh(geometry,material);mesh.userData.view=view;mesh.renderOrder=0;objects.push(mesh);
    const corners=nextCameras[view].plane.map(p=>new THREE.Vector3(...p));
    const edge=new THREE.LineLoop(new THREE.BufferGeometry().setFromPoints(corners),new THREE.LineBasicMaterial({color:view==='AP'?0x43d9b1:0x63a9ff,transparent:true,depthWrite:false}));
    edge.renderOrder=0;objects.push(edge);
  }
  return objects;
}
async function fetchAsset(url,type='json'){
  const response=await fetch(url,{signal:AbortSignal.timeout(20000)});
  if(!response.ok)throw new Error(`Asset request failed (${response.status}).`);
  return type==='json'?response.json():response.arrayBuffer();
}
function refreshCaseControls(){
  const index=caseList.indexOf(currentCase);
  actionButtons.forEach(b=>b.disabled=caseLoading||!state.ready);
  actionInputs.forEach(el=>el.disabled=caseLoading||!state.ready);
  // Allow another selection after a failed first load.
  $('case-select').disabled=caseLoading;
  $('case-prev').disabled=caseLoading||index<=0;
  $('case-next').disabled=caseLoading||index<0||index===caseList.length-1;
}
async function selectCase(id){
  if(caseLoading)return;
  const entry=caseList.find(item=>item.id===id);if(!entry)return;
  caseLoading=true;const wasReady=state.ready;state.ready=false;
  predicted.visible=false;reference.visible=false;imagePlanes.visible=false;$('backdrop').hidden=true;
  $('loading').hidden=false;$('loading').textContent=`Loading ${entry.label}…`;
  $('case-status').textContent=`Loading ${entry.label}…`;refreshCaseControls();
  const pending=[],nextTextures={};
  try{
    const nextCameras=(await fetchAsset(caseAsset('cameras.json',entry))).views;
    const loader=new STLLoader();let loaded=0;
    const tasks=['recons','gt'].flatMap(folder=>[1,2,3,4,5].map(level=>({folder,level})));
    async function meshWorker(){
      while(tasks.length){
        const {folder,level}=tasks.shift();
        const geometry=loader.parse(await fetchAsset(caseAsset(`${folder}/L${level}.stl`,entry),'buffer'));smoothNormals(geometry);
        const material=new THREE.MeshStandardMaterial({color:folder==='gt'?0xff9f86:colors[level-1],roughness:.49,metalness:.07,side:THREE.DoubleSide,transparent:true,depthWrite:false});
        const mesh=new THREE.Mesh(geometry,material);mesh.userData.level=level;mesh.userData.kind=folder;mesh.renderOrder=folder==='gt'?2:1;pending.push(mesh);
        $('loading').textContent=`Loading ${entry.label} · surfaces ${++loaded} / 10…`;
        await new Promise(resolve=>setTimeout(resolve,0));
      }
    }
    const results=await Promise.allSettled([
      ...['raw','seg'].flatMap(source=>['AP','ML'].map(async view=>{
        const response=await fetch(caseAsset(`${source}/${view}.png`,entry),{signal:AbortSignal.timeout(20000)});
        if(!response.ok)throw new Error('Image request failed.');
        const blob=await response.blob(),url=URL.createObjectURL(blob),image=new Image();
        try{image.src=url;await image.decode();const texture=new THREE.Texture(image);texture.colorSpace=THREE.SRGBColorSpace;texture.needsUpdate=true;nextTextures[`${source}-${view}`]=texture;}
        finally{URL.revokeObjectURL(url);}
      })),
      ...Array.from({length:4},meshWorker)
    ]);
    if(results.some(result=>result.status==='rejected'))throw new Error('Some case assets could not be loaded. Select a case to retry.');
    disposeMeshes([...predicted.children,...reference.children]);
    disposeMeshes([...imagePlanes.children]);Object.values(caseTextures).forEach(texture=>texture.dispose());caseTextures=nextTextures;
    imagePlanes.add(...makeImagePlanes(nextCameras,nextTextures));
    for(const mesh of pending)(mesh.userData.kind==='gt'?reference:predicted).add(mesh);
    currentCase=entry;cameras=nextCameras;predicted.visible=true;reference.visible=true;
    bounds.setFromObject(predicted);bounds.getCenter(center);radius=bounds.getSize(new THREE.Vector3()).length()/2;
    resetFree();state.ready=true;
    const showImage=$('show-image').checked;
    setView(state.view,{reset:true});$('show-image').checked=showImage;updateLayers();
    $('case-select').value=entry.id;$('case-badge').textContent=entry.label.toUpperCase();
    $('case-status').textContent='Ready to explore';
    $('loading').hidden=true;
  }catch(error){
    disposeMeshes(pending);Object.values(nextTextures).forEach(texture=>texture.dispose());state.ready=wasReady;predicted.visible=wasReady;reference.visible=wasReady;
    if(currentCase){$('case-select').value=currentCase.id;refreshImages();updateLayers();}
    $('loading').textContent=`Unable to load ${entry.label}. Select a case to retry.`;
    $('case-status').textContent='Loading failed. Please select a case to retry.';
    console.error(error);
  }finally{caseLoading=false;refreshCaseControls();if(state.ready)updateLayers();}
}
async function load(){
  caseList=(await (window.caseLibraryPromise||fetchAsset(new URL('./data/cases.json',import.meta.url)))).cases;
  if(!caseList.length)throw new Error('The case library is empty.');
  if(!$('case-select').options.length)for(const entry of caseList){const option=document.createElement('option');option.value=entry.id;option.textContent=entry.label;$('case-select').appendChild(option);}
  $('case-select').addEventListener('change',()=>selectCase($('case-select').value));
  $('case-prev').onclick=()=>selectCase(caseList[caseList.indexOf(currentCase)-1]?.id);
  $('case-next').onclick=()=>selectCase(caseList[caseList.indexOf(currentCase)+1]?.id);
  await selectCase(caseList[0].id);
  document.querySelectorAll('[data-stage]').forEach(b=>b.setAttribute('aria-pressed',b.dataset.stage===state.stage));
  window.lumbarDemo={getState:()=>({caseId:currentCase?.id,caseCount:caseList.length,view:state.view,source:state.source,levels:[...state.levels],ready:state.ready,meshes:predicted.children.length+reference.children.length,gt:$('show-gt').checked,image:$('show-image').checked,imagePlanes:imagePlanes.visible}),renderer,scene,getCamera:()=>camera};
}
const resize=new ResizeObserver(()=>{const size=$('viewport').clientWidth;renderer.setSize(size,size,false);});resize.observe($('viewport'));
renderer.domElement.addEventListener('webglcontextlost',e=>{e.preventDefault();$('loading').hidden=false;$('loading').textContent='Graphics context lost. Refresh this page to reload the viewer.';});
function animate(){requestAnimationFrame(animate);if(controls.enabled)controls.update();renderer.render(scene,camera);}animate();
await load();

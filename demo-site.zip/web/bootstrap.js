// Load the small library independently of the 3D module and its GPU startup.
const status=document.getElementById('case-status');
let viewerUnavailable=false;
window.caseLibraryPromise=fetch(new URL('./data/cases.json',import.meta.url),{signal:AbortSignal.timeout(15000)})
  .then(response=>{if(!response.ok)throw new Error('Case library request failed.');return response.json();})
  .then(library=>{
    if(!library.cases?.length)throw new Error('The case library is empty.');
    const select=document.getElementById('case-select');
    for(const entry of library.cases){const option=document.createElement('option');option.value=entry.id;option.textContent=entry.label;select.appendChild(option);}
    const count=document.getElementById('case-count');if(count)count.textContent=String(library.cases.length).padStart(2,'0');
    if(!viewerUnavailable)status.textContent='Preparing 3D viewer…';
    return library;
  });
// Attach a handler immediately, even while the larger module is still loading.
window.caseLibraryPromise.catch(error=>{status.textContent='Case library unavailable. Refresh to retry.';console.error(error);});
import('./app.js?v=neon-top5-5').catch(error=>{
  viewerUnavailable=true;
  const el=document.getElementById('loading');el.hidden=false;
  el.textContent='The 3D viewer could not start. Refresh to retry, or use a browser with WebGL 2 enabled. Static image previews remain available.';
  status.textContent='3D viewer unavailable. Refresh to retry.';
  const viewerStatus=document.getElementById('viewer-status');if(viewerStatus)viewerStatus.textContent='3D unavailable · image previews available';
  document.querySelectorAll('.workspace button,.workspace input,.workspace select,.pipeline button,.case-navigation button,.case-navigation select').forEach(control=>control.disabled=true);
  document.querySelectorAll('.image-card').forEach(card=>{card.disabled=true;card.title='Static preview — the 3D viewer is unavailable';});
  console.error(error);
});

// Load the small library independently of the 3D module and its GPU startup.
const status=document.getElementById('case-status');
window.caseLibraryPromise=fetch(new URL('./data/cases.json',import.meta.url),{signal:AbortSignal.timeout(15000)})
  .then(response=>{if(!response.ok)throw new Error('Case library request failed.');return response.json();})
  .then(library=>{
    if(!library.cases?.length)throw new Error('The case library is empty.');
    const select=document.getElementById('case-select');
    for(const entry of library.cases){const option=document.createElement('option');option.value=entry.id;option.textContent=entry.label;select.appendChild(option);}
    status.textContent='Preparing 3D viewer…';
    return library;
  });
// Attach a handler immediately, even while the larger module is still loading.
window.caseLibraryPromise.catch(error=>{status.textContent='Case library unavailable. Refresh to retry.';console.error(error);});
import('./app.js?v=publish-1').catch(error=>{
  const el=document.getElementById('loading');el.hidden=false;
  el.textContent='Unable to load the viewer. Refresh to retry in a browser with WebGL 2 support.';
  status.textContent='Viewer unavailable. Refresh to retry.';console.error(error);
});

import * as THREE from 'three';
import { OrbitControls } from './vendor/OrbitControls.js';
import { STLLoader } from './vendor/STLLoader.js';
import { weldTriangleSoup, meanValueWeights, surfaceWeights, mapWeights, containsPoint, validateCorrespondence } from './correspondence.js?v=correspondence-3';

const $ = id => document.getElementById(id);
const section = $('mapping');
const palette = [0xf5c86a, 0x7de3d1, 0xf391b4, 0xa6b4ff, 0xffa97c, 0xb7e47a];
const levelColors = [0x43d9b1, 0x63a9ff, 0xb294f5, 0xf2cc60, 0xf080b8];
const dataRoot = new URL('../', import.meta.url);
const cache = new Map();
let panels, library, templateEntry, sourceData, targetData, selectedRay, points = [], active = -1;
let started = false, busy = false, visible = false, mode = 'interior', epoch = 0, cloud = [];

function message(text, error = false) {
  $('mapping-status').textContent = text;
  $('mapping-status').classList.toggle('is-error', error);
}
function setBusy(value) {
  busy = value;
  section.querySelectorAll('.mapping-controls button, .mapping-controls select, .mapping-controls input, .mapping-actions button').forEach(el => el.disabled = value);
  $('map-depth').disabled = value || mode !== 'interior' || !selectedRay;
  panels?.forEach(p => p.controls.enabled = !value);
  section.setAttribute('aria-busy', String(value));
}
async function getData(entry, level) {
  const url = new URL(`${entry.base}recons/L${level}.stl`, dataRoot).href;
  if (!cache.has(url)) cache.set(url, (async () => {
    const response = await fetch(url, { signal: AbortSignal.timeout(20000) });
    if (!response.ok) throw new Error('Mesh request failed.');
    const soup = new STLLoader().parse(await response.arrayBuffer());
    const data = weldTriangleSoup(soup.attributes.position.array);
    soup.dispose();
    const geometry = new THREE.BufferGeometry();
    geometry.setAttribute('position', new THREE.Float32BufferAttribute(data.vertices, 3));
    geometry.setIndex(new THREE.BufferAttribute(data.faces, 1));
    geometry.computeVertexNormals(); geometry.computeBoundingBox();
    data.center = geometry.boundingBox.getCenter(new THREE.Vector3());
    data.radius = geometry.boundingBox.getSize(new THREE.Vector3()).length() / 2;
    data.geometry = geometry;
    return data;
  })().catch(error => { cache.delete(url); throw error; }));
  return cache.get(url);
}
function makePanel(hostId, source) {
  const host = $(hostId), scene = new THREE.Scene();
  const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
  renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
  renderer.setClearColor(0x071023, 1);
  renderer.domElement.setAttribute('aria-label', source ? 'Case 000 SSM template. Click the mesh to choose a point.' : 'Target reconstruction with transferred points.');
  renderer.domElement.setAttribute('role', 'img');
  host.appendChild(renderer.domElement);
  const camera = new THREE.PerspectiveCamera(35, 1, .1, 5000);
  const controls = new OrbitControls(camera, renderer.domElement);
  controls.enableDamping = false;
  const material = new THREE.MeshStandardMaterial({ color: source ? 0x8cdcf5 : 0xb294f5, transparent: true, opacity: .38, roughness: .42, metalness: .12, side: THREE.DoubleSide, depthWrite: false });
  const mesh = new THREE.Mesh(new THREE.BufferGeometry(), material);
  mesh.renderOrder = 1;
  const markers = new THREE.Group();
  const anatomy = new THREE.Group();
  anatomy.add(mesh, markers);
  // The supplied SSM and imaging meshes use different axis conventions.
  // This fixed viewing rotation does not change native mapping coordinates.
  if (source) anatomy.rotation.x = -Math.PI / 2;
  scene.add(anatomy, new THREE.HemisphereLight(0xe4ffff, 0x20434b, 2.3));
  const lamp = new THREE.DirectionalLight(0xffffff, 2.4); lamp.position.set(80, 100, 180); scene.add(lamp);
  const observer = new ResizeObserver(() => {
    const rect = host.getBoundingClientRect();
    if (!rect.width || !rect.height) return;
    renderer.setSize(rect.width, rect.height, false);
    camera.aspect = rect.width / rect.height; camera.updateProjectionMatrix();
  });
  observer.observe(host);
  renderer.domElement.addEventListener('webglcontextlost', event => {
    event.preventDefault(); setBusy(true); visible = false;
    message('Graphics context lost. Refresh to reload the point mapping demo.', true);
  });
  return { host, scene, renderer, camera, controls, mesh, markers, data: null };
}
function syncCameras() {
  let syncing = false;
  panels.forEach((panel, i) => panel.controls.addEventListener('change', () => {
    if (syncing || !panels[0].data) return;
    syncing = true;
    const other = panels[1 - i];
    other.camera.position.copy(panel.camera.position); other.camera.quaternion.copy(panel.camera.quaternion);
    other.controls.target.copy(panel.controls.target); other.controls.update();
    syncing = false;
  }));
}
function resetCameras() {
  const radius = Math.max(sourceData.radius, targetData.radius);
  const direction = new THREE.Vector3(1.05, .45, 1.5).normalize();
  panels.forEach(panel => {
    panel.controls.minDistance = radius * 1.08;
    panel.controls.maxDistance = radius * 15;
    panel.camera.position.copy(direction).multiplyScalar(radius / Math.sin(THREE.MathUtils.degToRad(17.5)) * .88);
    panel.controls.target.set(0, 0, 0); panel.controls.update();
  });
}
function disposeMarkers(panel) {
  for (const child of [...panel.markers.children]) {
    child.geometry?.dispose(); child.material?.dispose(); panel.markers.remove(child);
  }
}
function drawMarkers() {
  panels.forEach((panel, which) => {
    disposeMarkers(panel);
    const radius = Math.max(sourceData.radius, targetData.radius) * .018;
    points.forEach((point, i) => {
      const position = which ? point.target : point.source;
      const sphere = new THREE.Mesh(new THREE.SphereGeometry(radius * (i === active ? 1.24 : 1), 16, 12), new THREE.MeshBasicMaterial({ color: palette[i % palette.length], transparent: true, opacity: 1, depthWrite: false, depthTest: false }));
      sphere.position.fromArray(position).sub(panel.data.center); sphere.renderOrder = 5;
      panel.markers.add(sphere);
    });
    if (cloud.length) {
      const positions = cloud.flatMap(point => {
        const p = new THREE.Vector3().fromArray(which ? point.target : point.source).sub(panel.data.center); return p.toArray();
      });
      const geometry = new THREE.BufferGeometry(); geometry.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
      const material = new THREE.PointsMaterial({ color: 0xa4efdf, size: radius * 1.5, transparent: true, opacity: .85, depthTest: false });
      const dots = new THREE.Points(geometry, material); dots.renderOrder = 3; panel.markers.add(dots);
    }
  });
}
const xyz = p => p.map(v => v.toFixed(2)).join(', ');
function updateReadout() {
  const list = $('map-points'); list.replaceChildren();
  points.forEach((point, i) => {
    const button = document.createElement('button'); button.className = 'mapped-point' + (i === active ? ' active' : '');
    button.setAttribute('aria-pressed', String(i === active));
    const dot = document.createElement('i'); dot.style.background = `#${palette[i % palette.length].toString(16)}`;
    const text = document.createElement('span'); text.textContent = `P${i + 1}`;
    button.append(dot, text); button.addEventListener('click', () => {
      active = i; selectedRay = point.ray || null;
      $('map-depth').value = Math.round(point.depth * 100);
      updateReadout(); drawMarkers();
    }); list.appendChild(button);
  });
  const point = points[active];
  $('map-source-coordinates').textContent = point ? xyz(point.source) : '—';
  $('map-target-coordinates').textContent = point ? xyz(point.target) : '—';
  $('map-source-location').textContent = point ? point.type === 'surface' ? 'On surface' : 'Inside source' : 'Choose a point';
  $('map-target-location').textContent = point ? point.inside ? point.type === 'surface' ? 'On surface' : 'Inside target' : 'Outside target' : '—';
  $('map-target-location').classList.toggle('is-error', !!point && !point.inside);
  $('map-residual').textContent = point ? `${point.residual.toExponential(1)} mm` : '—';
  $('map-depth-value').value = `${$('map-depth').value}%`;
  $('map-depth').disabled = busy || !point?.ray || point.type !== 'interior' || mode !== 'interior';
  if (point && !point.inside) message('This interpolated point falls outside the target shell. Try another location; an interior deformation is not guaranteed to preserve containment.', true);
  else if (cloud.some(sample => !sample.inside)) message(`${cloud.filter(sample => !sample.inside).length} cloud samples fall outside the target shell. Interior interpolation is not guaranteed to preserve containment.`, true);
  else if (point) message(point.type === 'surface' ? 'Surface point transferred with the same triangle and barycentric coordinates.' : 'Interior point transferred using mean value coordinates of the corresponding boundary.');
  else message('Click the Case 000 mesh to place a point. Drag to rotate either view.');
}
function buildPoint(source, weights, type, ray = null, depth = .5) {
  const target = mapWeights(weights, targetData);
  const reproduced = mapWeights(weights, sourceData);
  return { source, target, weights, type, ray, depth, residual: Math.hypot(...source.map((v, i) => v - reproduced[i])), inside: containsPoint(targetData, target) };
}
function putPoint(point, replace = false) {
  if (replace && active >= 0) points[active] = point;
  else if (points.length < 6) { points.push(point); active = points.length - 1; }
  else { points[active] = point; }
  selectedRay = point.ray;
  $('map-depth').value = Math.round(point.depth * 100);
  drawMarkers(); updateReadout();
}
function castSegments(ray) {
  panels[0].scene.updateMatrixWorld(true);
  const raycaster = new THREE.Raycaster(); raycaster.ray.copy(ray);
  const hits = raycaster.intersectObject(panels[0].mesh, false);
  const unique = hits.filter((hit, i) => i === 0 || Math.abs(hit.distance - hits[i - 1].distance) > 1e-5);
  const segments = [];
  for (let i = 0; i + 1 < unique.length; i += 2) {
    const a = panels[0].mesh.worldToLocal(unique[i].point.clone()), b = panels[0].mesh.worldToLocal(unique[i + 1].point.clone());
    if (a.distanceTo(b) > sourceData.radius * .005 && containsPoint(sourceData, a.clone().lerp(b, .5).toArray())) segments.push({ a: a.toArray(), b: b.toArray(), hit: unique[i] });
  }
  return { hits, segments };
}
function fromSegment(segment, depth) {
  const source = segment.a.map((v, i) => v + (segment.b[i] - v) * depth);
  return buildPoint(source, meanValueWeights(sourceData, source), 'interior', segment, depth);
}
function surfacePoint(hit) {
  const p = panels[0].mesh.worldToLocal(hit.point.clone()), index = hit.faceIndex * 3;
  const vertices = [0, 1, 2].map(i => new THREE.Vector3().fromArray(sourceData.vertices, sourceData.faces[index + i] * 3));
  const barycentric = THREE.Triangle.getBarycoord(p, ...vertices, new THREE.Vector3()).toArray();
  return buildPoint(p.toArray(), surfaceWeights(sourceData, hit.faceIndex, barycentric), 'surface', null, 0);
}
function initializePoint() {
  const panel = panels[0], direction = new THREE.Vector3(1.05, .45, 1.5).normalize();
  const candidates = [];
  for (const x of [0, -.2, .2]) for (const z of [0, -.2, .2]) {
    const aim = new THREE.Vector3(x * sourceData.radius, 0, z * sourceData.radius);
    const ray = new THREE.Ray(aim.clone().addScaledVector(direction, sourceData.radius * 4), direction.clone().negate());
    candidates.push(...castSegments(ray).segments);
  }
  candidates.sort((a, b) => new THREE.Vector3().fromArray(b.a).distanceTo(new THREE.Vector3().fromArray(b.b)) - new THREE.Vector3().fromArray(a.a).distanceTo(new THREE.Vector3().fromArray(a.b)));
  for (const segment of candidates) {
    try {
      const point = mode === 'surface' ? surfacePoint(segment.hit) : fromSegment(segment, .5);
      points = []; active = -1; putPoint(point); return;
    } catch { /* Try another actual closed-mesh intersection. */ }
  }
  points = []; active = -1; selectedRay = null; updateReadout();
}
async function loadPair(resetPoints) {
  const request = ++epoch; setBusy(true); message('Loading corresponding meshes…');
  try {
    const level = Number($('map-level').value);
    const sourceEntry = templateEntry;
    const targetEntry = library.find(entry => entry.id === $('map-target').value);
    const [source, target] = await Promise.all([getData(sourceEntry, level), getData(targetEntry, level)]);
    if (request !== epoch) return;
    validateCorrespondence(source, target);
    sourceData = source; targetData = target;
    panels.forEach((panel, i) => {
      panel.data = i ? target : source; panel.mesh.geometry.dispose();
      panel.mesh.geometry = panel.data.geometry.clone(); panel.mesh.position.copy(panel.data.center).negate();
      panel.mesh.material.color.setHex(i ? levelColors[level - 1] : 0x8cdcf5);
    });
    $('map-target-name').textContent = targetEntry.label;
    $('map-level-label').textContent = `L${level}`;
    $('map-topology').textContent = `${source.vertices.length / 3} corresponding vertices · ${source.faces.length / 3} triangles`;
    if (resetPoints) cloud = [];
    else cloud = cloud.map(sample => {
      const target = mapWeights(sample.weights, targetData);
      return { ...sample, target, inside: containsPoint(targetData, target) };
    });
    $('map-cloud').setAttribute('aria-pressed', String(cloud.length > 0));
    if (resetPoints || !points.length) { resetCameras(); initializePoint(); }
    else {
      points = points.map(point => buildPoint(point.source, point.weights, point.type, point.ray, point.depth));
      drawMarkers(); updateReadout();
    }
    section.dataset.ready = 'true';
  } catch (error) {
    message('Point mapping could not load. Use Retry to load the mesh pair again.', true);
    console.error('Correspondence viewer:', error);
  } finally { if (request === epoch) setBusy(false); }
}
async function showCloud() {
  if (cloud.length) { cloud = []; drawMarkers(); $('map-cloud').setAttribute('aria-pressed', 'false'); return; }
  setBusy(true); message('Sampling and mapping interior points…');
  try {
    // Yield one paint before evaluating the small, deterministic interior lattice.
    await new Promise(resolve => requestAnimationFrame(resolve));
    const box = sourceData.geometry.boundingBox, size = box.getSize(new THREE.Vector3());
    const samples = [];
    for (let z = 1; z <= 5; z++) for (let y = 1; y <= 5; y++) for (let x = 1; x <= 5; x++) {
      const p = [box.min.x + size.x * x / 6, box.min.y + size.y * y / 6, box.min.z + size.z * z / 6];
      if (containsPoint(sourceData, p)) samples.push(p);
    }
    cloud = samples.filter((_, i) => i % Math.max(1, Math.ceil(samples.length / 40)) === 0).map(source => {
      const weights = meanValueWeights(sourceData, source), target = mapWeights(weights, targetData);
      return { source, target, weights, inside: containsPoint(targetData, target) };
    });
    drawMarkers(); $('map-cloud').setAttribute('aria-pressed', 'true');
    const outside = cloud.filter(point => !point.inside).length;
    message(`${cloud.length} source-interior points transferred. ${outside ? `${outside} fall outside the target shell; this interpolation is not guaranteed to preserve containment.` : 'All mapped samples are inside the target shell.'}`, !!outside);
  } catch (error) { cloud = []; message('The interior cloud could not be computed for this selection.', true); console.error(error); }
  finally { setBusy(false); }
}
function bindPicking() {
  const panel = panels[0], canvas = panel.renderer.domElement;
  let down;
  canvas.addEventListener('pointerdown', event => { if (event.button === 0) down = [event.clientX, event.clientY]; });
  canvas.addEventListener('pointerup', event => {
    if (!down || busy || event.button !== 0) return;
    const moved = Math.hypot(event.clientX - down[0], event.clientY - down[1]); down = null;
    if (moved > 5) return;
    try {
      const rect = canvas.getBoundingClientRect();
      const pointer = new THREE.Vector2((event.clientX - rect.left) / rect.width * 2 - 1, -(event.clientY - rect.top) / rect.height * 2 + 1);
      const raycaster = new THREE.Raycaster(); raycaster.setFromCamera(pointer, panel.camera);
      const { hits, segments } = castSegments(raycaster.ray);
      if (mode === 'surface' && hits.length) putPoint(surfacePoint(hits[0]));
      else if (segments.length) putPoint(fromSegment(segments[0], Math.max(.01, Math.min(.99, Number($('map-depth').value) / 100))));
      else message('Choose a point on the visible template mesh. Empty space and the vertebral foramen are not bone.');
    } catch (error) { message('This point could not be interpolated. Choose another location on the template.', true); console.error(error); }
  });
}
async function start() {
  if (started) return; started = true;
  try {
    const manifest = await (window.caseLibraryPromise || fetch(new URL('./data/cases.json', import.meta.url)).then(r => r.json()));
    library = manifest.cases;
    templateEntry = manifest.template;
    if (!templateEntry?.base) throw new Error('The SSM template is missing from the case library.');
    for (const entry of library) {
      const option = document.createElement('option'); option.value = entry.id; option.textContent = entry.label; $('map-target').appendChild(option);
    }
    panels = [makePanel('map-source-canvas', true), makePanel('map-target-canvas', false)]; syncCameras(); bindPicking();
    $('map-level').addEventListener('change', () => loadPair(true));
    $('map-target').addEventListener('change', () => loadPair(false));
    $('map-retry').addEventListener('click', () => loadPair(true));
    $('map-reset').addEventListener('click', resetCameras);
    $('map-clear').addEventListener('click', () => { points = []; active = -1; selectedRay = null; cloud = []; $('map-cloud').setAttribute('aria-pressed', 'false'); drawMarkers(); updateReadout(); });
    $('map-cloud').addEventListener('click', showCloud);
    $('map-shell-opacity').addEventListener('input', () => { panels.forEach(p => p.mesh.material.opacity = Number($('map-shell-opacity').value) / 100); $('map-shell-opacity-value').value = `${$('map-shell-opacity').value}%`; });
    $('map-depth').addEventListener('input', () => {
      if (!selectedRay || busy || mode !== 'interior') return;
      try { putPoint(fromSegment(selectedRay, Number($('map-depth').value) / 100), true); }
      catch (error) { message('This depth could not be interpolated. Try a different point.', true); console.error(error); }
    });
    section.querySelectorAll('[data-map-mode]').forEach(button => button.addEventListener('click', () => {
      mode = button.dataset.mapMode;
      section.querySelectorAll('[data-map-mode]').forEach(b => { b.classList.toggle('active', b === button); b.setAttribute('aria-pressed', String(b === button)); });
      initializePoint();
    }));
    function animate() {
      requestAnimationFrame(animate);
      if (!visible || document.hidden || !sourceData) return;
      panels.forEach(panel => { panel.controls.update(); panel.renderer.render(panel.scene, panel.camera); });
    }
    requestAnimationFrame(animate);
    await loadPair(true);
  } catch (error) { message('The mapping viewer needs WebGL 2. Refresh to retry.', true); console.error(error); }
}
new IntersectionObserver(entries => {
  visible = entries[0].isIntersecting;
  if (visible) start();
}, { rootMargin: '300px' }).observe(section);

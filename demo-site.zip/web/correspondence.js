/**
 * Corresponding reconstructed surfaces -> a volumetric geometric extension.
 *
 * The reconstruction supplies homologous boundary vertex indices. Interior
 * weights use 3D mean value coordinates (Ju, Schaefer & Warren, SIGGRAPH 2005,
 * Figure 4, https://people.eecs.berkeley.edu/~jrs/meshpapers/meanvalue.pdf).
 * This is an added demo interpolation, not measured anatomical accuracy, and
 * does not establish a bijection or prevent foldovers on a nonconvex target.
 *
 * Mesh: {vertices: Float64Array of xyz triples, faces: Uint32Array of triples}.
 * Mesh arrays must be treated as immutable; validation metadata is cached.
 */

const metadata = new WeakMap();
const dot = (a, b) => a[0]*b[0]+a[1]*b[1]+a[2]*b[2];
const cross = (a, b) => [a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0]];
const subtract = (a, b) => [a[0]-b[0], a[1]-b[1], a[2]-b[2]];
const vertex = (values, index) => [values[3*index], values[3*index+1], values[3*index+2]];
const length = a => Math.hypot(a[0],a[1],a[2]);
const clampCos = c => Math.max(-1, Math.min(1,c));

function checkPoint(point) {
  if (!point || point.length !== 3 || !Array.from(point).every(Number.isFinite)) {
    throw new TypeError('Point must contain three finite coordinates.');
  }
}

function getMetadata(mesh) {
  if (!mesh || typeof mesh !== 'object') throw new TypeError('Expected an indexed triangle mesh.');
  if (metadata.has(mesh)) return metadata.get(mesh);
  const {vertices, faces} = mesh;
  if (!(vertices instanceof Float64Array || vertices instanceof Float32Array) ||
      !(faces instanceof Uint32Array) || vertices.length < 12 || vertices.length % 3 ||
      faces.length < 12 || faces.length % 3) {
    throw new TypeError('Mesh requires flat xyz vertices and Uint32Array triangle indices.');
  }
  const min = [Infinity,Infinity,Infinity], max = [-Infinity,-Infinity,-Infinity];
  let largest = 0;
  for (let i=0;i<vertices.length;i++) {
    const v=vertices[i];
    if (!Number.isFinite(v)) throw new Error('Mesh contains a nonfinite vertex.');
    const axis=i%3; min[axis]=Math.min(min[axis],v); max[axis]=Math.max(max[axis],v);
    largest=Math.max(largest,Math.abs(v));
  }
  const scale=length(subtract(max,min));
  if (!(scale>0)) throw new Error('Mesh has zero extent.');
  const edges=new Map(), count=vertices.length/3;
  for(let i=0;i<faces.length;i+=3) {
    const ids=[faces[i],faces[i+1],faces[i+2]];
    if(ids.some(id=>id>=count)||new Set(ids).size!==3) throw new Error('Mesh has an invalid triangle.');
    const a=vertex(vertices,ids[0]), b=vertex(vertices,ids[1]), c=vertex(vertices,ids[2]);
    if(length(cross(subtract(b,a),subtract(c,a)))<=scale*scale*1e-16) {
      throw new Error('Mesh has a degenerate triangle.');
    }
    for(let j=0;j<3;j++) {
      const a=ids[j],b=ids[(j+1)%3],key=a<b?`${a}:${b}`:`${b}:${a}`;
      const e=edges.get(key)||[0,0];e[0]++;e[1]+=a<b?1:-1;edges.set(key,e);
    }
  }
  if(Array.from(edges.values()).some(([count,direction])=>count!==2||direction!==0)) {
    throw new Error('Mean value coordinates require a closed, consistently oriented mesh.');
  }
  const result={min,max,scale,count,tolerance:scale*1e-11+largest*32*Number.EPSILON};
  metadata.set(mesh,result);
  return result;
}

/** Exact-coordinate welding preserves first-seen vertices and STL face order.
 * No rounding/nearest-neighbour welding: it must not invent correspondences.
 */
export function weldTriangleSoup(positions) {
  if (!(positions instanceof Float32Array || positions instanceof Float64Array) ||
      positions.length%9 || positions.length===0) throw new TypeError('Expected triangle-soup xyz positions.');
  const index=new Map(),vertices=[],faces=new Uint32Array(positions.length/3);
  for(let i=0;i<positions.length;i+=3) {
    const x=positions[i],y=positions[i+1],z=positions[i+2];
    if(![x,y,z].every(Number.isFinite)) throw new Error('Triangle soup contains a nonfinite vertex.');
    const key=`${x},${y},${z}`;
    let id=index.get(key);
    if(id===undefined) {id=vertices.length/3;index.set(key,id);vertices.push(x,y,z);}
    faces[i/3]=id;
  }
  const mesh={vertices:new Float64Array(vertices),faces};getMetadata(mesh);return mesh;
}

export function validateCorrespondence(source,target) {
  const a=getMetadata(source),b=getMetadata(target);
  if(a.count!==b.count||source.faces.length!==target.faces.length||
      source.faces.some((id,i)=>id!==target.faces[i])) {
    throw new Error('Surfaces do not have the same indexed triangle topology.');
  }
  return true;
}

/** Boundary coordinates on a known face, in that face's stored vertex order. */
export function surfaceWeights(mesh,faceIndex,barycentric) {
  const {count}=getMetadata(mesh);
  if(!Number.isInteger(faceIndex)||faceIndex<0||faceIndex>=mesh.faces.length/3) throw new RangeError('Invalid face index.');
  checkPoint(barycentric);
  const sum=barycentric[0]+barycentric[1]+barycentric[2];
  if(Math.abs(sum-1)>1e-8||barycentric.some(v=>v < -1e-9 || v > 1+1e-9)) {
    throw new RangeError('Surface barycentric coordinates must lie on the triangle and sum to one.');
  }
  const weights=new Float64Array(count);
  // This normalization only removes roundoff in input barycentric coordinates.
  for(let k=0;k<3;k++) weights[mesh.faces[3*faceIndex+k]]=barycentric[k]/sum;
  return weights;
}

function boundaryWeights(mesh,point,info) {
  const {vertices,faces}=mesh,{tolerance,count}=info;
  for(let i=0;i<count;i++) {
    if(length(subtract(vertex(vertices,i),point))<=tolerance) {
      const w=new Float64Array(count);w[i]=1;return w;
    }
  }
  for(let f=0;f<faces.length;f+=3) {
    const a=vertex(vertices,faces[f]),ab=subtract(vertex(vertices,faces[f+1]),a),
      ac=subtract(vertex(vertices,faces[f+2]),a),ap=subtract(point,a),n=cross(ab,ac),nn=dot(n,n);
    if(Math.abs(dot(n,ap))>tolerance*Math.sqrt(nn)) continue;
    // Oriented areas avoid the nearly parallel edge dot-product determinant.
    const b=dot(cross(ap,ac),n)/nn,c=dot(cross(ab,ap),n)/nn,aWeight=1-b-c;
    const baryTolerance=tolerance/Math.max(length(ab),length(ac));
    if(aWeight>=-baryTolerance&&b>=-baryTolerance&&c>=-baryTolerance) {
      const w=new Float64Array(count);w[faces[f]]=aWeight;w[faces[f+1]]=b;w[faces[f+2]]=c;return w;
    }
  }
  return null;
}

function windingNumber(mesh,point) {
  let total=0,correction=0;
  for(let f=0;f<mesh.faces.length;f+=3) {
    const u=[];
    for(let k=0;k<3;k++) {const v=subtract(vertex(mesh.vertices,mesh.faces[f+k]),point),d=length(v);u.push(v.map(x=>x/d));}
    const angle=2*Math.atan2(dot(u[0],cross(u[1],u[2])),1+dot(u[0],u[1])+dot(u[1],u[2])+dot(u[2],u[0]));
    const y=angle-correction,t=total+y;correction=(t-total)-y;total=t;
  }
  return total/(4*Math.PI);
}

/** Solid-angle winding handles the spinal canal; a bounding box cannot. */
export function containsPoint(mesh,point) {
  checkPoint(point);const info=getMetadata(mesh);
  if(point.some((v,i)=>v<info.min[i]-info.tolerance||v>info.max[i]+info.tolerance)) return false;
  if(boundaryWeights(mesh,point,info)) return true;
  return Math.abs(windingNumber(mesh,point))>.5;
}

/** Normalized signed MVC. Negative weights on nonconvex cages are intentional.
 * Only interior/boundary queries are offered in this demo; exterior queries fail.
 */
export function meanValueWeights(mesh,point) {
  checkPoint(point);const info=getMetadata(mesh),boundary=boundaryWeights(mesh,point,info);
  if(boundary) return boundary;
  if(Math.abs(windingNumber(mesh,point))<=.5) throw new RangeError('Point is outside the closed source surface.');
  const {vertices,faces}=mesh,weights=new Float64Array(info.count),distances=new Float64Array(info.count),u=new Float64Array(vertices.length);
  for(let i=0;i<info.count;i++) {
    const v=subtract(vertex(vertices,i),point),d=length(v);distances[i]=d;
    for(let axis=0;axis<3;axis++) u[3*i+axis]=v[axis]/d;
  }
  for(let f=0;f<faces.length;f+=3) {
    const ids=[faces[f],faces[f+1],faces[f+2]],v=ids.map(i=>vertex(u,i)),theta=[],sine=[];
    const determinant=dot(v[0],cross(v[1],v[2]));
    // A coplanar triangle not containing the point contributes zero.
    if(Math.abs(determinant)<1e-15) continue;
    for(let i=0;i<3;i++) {
      const a=v[(i+1)%3],b=v[(i+2)%3];
      // Equivalent to 2 asin(|a-b|/2), but stable also near pi.
      theta[i]=2*Math.atan2(length(subtract(a,b)),length([a[0]+b[0],a[1]+b[1],a[2]+b[2]]));
      sine[i]=length(cross(a,b));
    }
    const h=(theta[0]+theta[1]+theta[2])/2,c=[],s=[];
    for(let i=0;i<3;i++) {
      const j=(i+1)%3,k=(i+2)%3;
      c[i]=clampCos(2*Math.sin(h)*Math.sin(h-theta[i])/(sine[j]*sine[k])-1);
      // Algebraically sign(det)*sqrt(1-c_i^2); the determinant form avoids
      // subtracting nearly equal values when a dihedral angle is near zero.
      s[i]=determinant/(sine[j]*sine[k]);
    }
    for(let i=0;i<3;i++) {
      const j=(i+1)%3,k=(i+2)%3;
      weights[ids[i]]+=(theta[i]-c[j]*theta[k]-c[k]*theta[j])/(distances[ids[i]]*sine[j]*s[k]);
    }
  }
  let sum=0,correction=0;
  for(const w of weights) {const y=w-correction,t=sum+y;correction=(t-sum)-y;sum=t;}
  if(!Number.isFinite(sum)||Math.abs(sum)<Number.EPSILON) throw new Error('Mean value coordinates are numerically singular.');
  for(let i=0;i<weights.length;i++) {
    weights[i]/=sum;
    if(!Number.isFinite(weights[i])) throw new Error('Mean value coordinates are not finite.');
  }
  const reconstructed=mapWeights(weights,mesh),residual=length(subtract(reconstructed,point));
  if(residual>info.scale*1e-7) throw new Error('Mean value coordinates failed the source identity precision check.');
  return weights;
}

/** Reuse source coordinates with homologous target vertices, without clamping. */
export function mapWeights(weights,targetMesh) {
  const {count}=getMetadata(targetMesh);
  if(!weights||weights.length!==count) throw new RangeError('Weight count does not match target vertex count.');
  const result=[0,0,0],correction=[0,0,0];let sum=0;
  for(let i=0;i<count;i++) {
    const w=weights[i];if(!Number.isFinite(w)) throw new Error('Mapping weights must be finite.');sum+=w;
    for(let axis=0;axis<3;axis++) {
      const y=w*targetMesh.vertices[3*i+axis]-correction[axis],t=result[axis]+y;
      correction[axis]=(t-result[axis])-y;result[axis]=t;
    }
  }
  if(Math.abs(sum-1)>1e-7) throw new Error('Mapping weights must sum to one.');
  return result;
}

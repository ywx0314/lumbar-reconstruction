// Run: node demo/web/geometry.test.js. No npm install required.
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {calibratedProjection,projectPixel,sub,dot,detectorPlaneData} from './geometry.js';
const {template,cases}=JSON.parse(fs.readFileSync(new URL('./data/cases.json',import.meta.url)));
assert.equal(template?.id,'case-000','Expected a separate Case 000 source template');
assert.equal(template.role,'template');
assert.equal(template.base,'web/templates/ssm/');
assert.equal(cases.length,5,'Expected five complete reconstructed cases');
assert.ok(cases.every(entry=>entry.role==='reconstruction'),'Only patient reconstructions belong in the case list');
assert.equal(new Set(cases.map(entry=>entry.id)).size,cases.length,'Patient case IDs must be unique');
assert.ok(cases.every(entry=>entry.id!==template.id),'The source template is not a radiograph case');
const unit=a=>{const n=Math.hypot(...a);return a.map(v=>v/n);};
const cross=(a,b)=>[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]];
// Independent transcription of the existing cone_beam_geometry.py ray-plane
// intersection (not a centered perspective-camera approximation).
function reference(point,c){
  const [tl,bl,br,tr]=c.plane;
  const x=unit(sub(tr,tl).map((v,i)=>(v+br[i]-bl[i])/2));
  const y=unit(sub(bl,tl).map((v,i)=>(v+br[i]-tr[i])/2));
  const normal=unit(cross(x,y)),center=tl.map((v,i)=>(v+br[i])/2);
  const ray=unit(sub(point,c.source));
  const t=dot(normal,sub(center,c.source))/dot(normal,ray);
  const p=ray.map((v,i)=>c.source[i]+t*v-tl[i]);
  return [512*dot(p,x)/Math.hypot(...sub(tr,tl)),512*dot(p,y)/Math.hypot(...sub(bl,tl))];
}
let count=0,maxError=0;
for(const entry of cases){
const caseBase=new URL('../'+entry.base,import.meta.url);
const {views}=JSON.parse(fs.readFileSync(new URL('cameras.json',caseBase)));
for(const [name,c] of Object.entries(views)){
  const m=calibratedProjection(c);
  const plane=detectorPlaneData(c);
  assert.deepEqual(plane.positions,c.plane.flat(),'Image plane must retain exact detector positions');
  assert.deepEqual(plane.indices,[0,1,2,0,2,3]);
  for(let i=0;i<4;i++){
    const pixel=projectPixel(plane.positions.slice(i*3,i*3+3),c);
    const display=[512-pixel[0],512-pixel[1]];
    const texture=plane.uvs.slice(i*2,i*2+2).map(v=>v*512);
    assert.ok(Math.hypot(...sub(display,texture))<.1,'Detector image orientation must agree with projection overlay');
  }
  for(const folder of ['recons','gt'])for(let level=1;level<=5;level++){
    const data=fs.readFileSync(new URL(`${folder}/L${level}.stl`,caseBase));
    const n=data.readUInt32LE(80);assert.equal(data.length,84+50*n);
    for(let f=0;f<n;f++)for(let v=0;v<3;v++){
      const start=84+50*f+12+v*12,p=[0,1,2].map(i=>data.readFloatLE(start+i*4));
      const q=[...sub(p,c.source),1],clip=[0,1,2,3].map(r=>dot(m.slice(r*4,r*4+4),q));
      assert.ok(clip[3]>0,`${name} model behind source`);
      const pixel=[(clip[0]/clip[3]+1)*256,(1-clip[1]/clip[3])*256];
      const mirrored=calibratedProjection(c,1,10000,true);
      const mirroredX=(dot(mirrored.slice(0,4),q)/clip[3]+1)*256;
      assert.ok(Math.abs(mirroredX-(512-pixel[0]))<1e-7,'explicit horizontal display transform');
      const expected=reference(p,c),direct=projectPixel(p,c);
      for(let axis=0;axis<2;axis++){
        const error=Math.abs(pixel[axis]-expected[axis]);maxError=Math.max(maxError,error);
        assert.ok(error<1e-7,`${name} projection mismatch ${error}`);
        assert.ok(Math.abs(direct[axis]-expected[axis])<1e-7);
      }count++;
    }
  }
  // Measured detector quads have small rounding/skew offsets (<0.05 px).
  // Check corner ordering to subpixel tolerance, while vertex equivalence above
  // remains strict at 1e-7 px against the original geometry algorithm.
  for(const [i,expected] of [[0,[0,0]],[1,[0,512]],[2,[512,512]],[3,[512,0]]]){
    const actual=projectPixel(c.plane[i],c);assert.ok(Math.hypot(...sub(actual,expected))<.1,`${entry.id} ${name} corner order`);
  }
}
}
console.log(`PASS: ${cases.length} cases; ${count} mesh vertices across both views; maximum projection error ${maxError.toExponential(3)} px.`);

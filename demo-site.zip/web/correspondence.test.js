// Run: node demo/web/correspondence.test.js. No third-party dependencies.
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {performance} from 'node:perf_hooks';
import {weldTriangleSoup,validateCorrespondence,surfaceWeights,meanValueWeights,mapWeights,containsPoint} from './correspondence.js';

const xyz=(mesh,i)=>Array.from(mesh.vertices.slice(3*i,3*i+3));
const subtract=(a,b)=>a.map((v,i)=>v-b[i]);
const norm=a=>Math.hypot(...a);
const cross=(a,b)=>[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]];
const distance=(a,b)=>norm(subtract(a,b));
const affine=p=>[1.2*p[0]+.17*p[1]-.09*p[2]+7, .06*p[0]+.82*p[1]+.14*p[2]-13, .12*p[0]-.08*p[1]+1.1*p[2]+4];
const transform=mesh=>({vertices:new Float64Array(Array.from({length:mesh.vertices.length/3},(_,i)=>affine(xyz(mesh,i))).flat()),faces:mesh.faces.slice()});
let maxIdentity=0,maxAffine=0,maxBoundary=0,maxPartition=0,queries=0,negativeQueries=0;
const timings=[];
function verifyPoint(mesh,point,label,statistics=null) {
  const start=performance.now(),weights=meanValueWeights(mesh,point);timings.push(performance.now()-start);
  const identity=distance(mapWeights(weights,mesh),point),a=transform(mesh);
  const affineError=distance(mapWeights(weights,a),affine(point)),partition=Math.abs(weights.reduce((s,w)=>s+w,0)-1);
  maxIdentity=Math.max(maxIdentity,identity);maxAffine=Math.max(maxAffine,affineError);maxPartition=Math.max(maxPartition,partition);queries++;
  if(weights.some(w=>w < -1e-10)) negativeQueries++;
  if(statistics) {
    statistics.queries++;
    statistics.identity=Math.max(statistics.identity,identity);
    statistics.affine=Math.max(statistics.affine,affineError);
    statistics.partition=Math.max(statistics.partition,partition);
  }
  assert.ok(identity<1e-6,`${label}: identity error ${identity}`);
  assert.ok(affineError<2e-6,`${label}: affine precision error ${affineError}`);
  assert.ok(partition<1e-12,`${label}: partition of unity ${partition}`);
  assert.ok(containsPoint(mesh,point),`${label}: point must be inside`);
  return weights;
}

// A tetrahedron has a unique affine coordinate system: use an independent
// hand-computed solution, not just the implementation's identity check.
const tetra={vertices:new Float64Array([0,0,0, 1,0,0, 0,1,0, 0,0,1]),faces:new Uint32Array([0,2,1,0,1,3,0,3,2,1,2,3])};
const tetraPoint=[.2,.25,.15],known=[.4,.2,.25,.15],tetraWeights=verifyPoint(tetra,tetraPoint,'tetrahedron');
tetraWeights.forEach((w,i)=>assert.ok(Math.abs(w-known[i])<1e-12,'tetrahedral affine coordinates'));
for(let i=0;i<4;i++) {
  const w=meanValueWeights(tetra,xyz(tetra,i));w.forEach((v,j)=>assert.equal(v,Number(i===j),'vertex interpolation'));
}
assert.deepEqual(Array.from(meanValueWeights(tetra,[.3,.2,0])),[.5,.3,.2,0],'triangle boundary branch');
assert.deepEqual(Array.from(meanValueWeights(tetra,[.4,0,0])),[.6,.4,0,0],'edge boundary branch');
for(const point of [[.2,.3,1e-9],[1e-9,1e-9,1e-9],[.5,1e-9,1e-9]]) {
  assert.ok(distance(mapWeights(meanValueWeights(tetra,point),tetra),point)<1e-13,'near face/vertex/edge remains numerically stable');
}
const exterior=mapWeights(new Float64Array([2,-1,0,0]),tetra);
assert.deepEqual(exterior,[-1,0,0],'signed weights are not clamped or snapped');
assert.equal(containsPoint(tetra,exterior),false,'an exterior map result stays exterior');
assert.throws(()=>meanValueWeights(tetra,[1,1,1]),/outside/);
assert.throws(()=>meanValueWeights(tetra,[NaN,0,0]),/finite/);
assert.throws(()=>surfaceWeights(tetra,0,[-.2,.7,.5]),/barycentric/);
assert.throws(()=>surfaceWeights(tetra,-1,[.2,.3,.5]),/face/);
assert.throws(()=>mapWeights(new Float64Array(4),tetra),/sum to one/);
const reverse={vertices:tetra.vertices,faces:tetra.faces.slice()};[reverse.faces[0],reverse.faces[1]]=[reverse.faces[1],reverse.faces[0]];
assert.throws(()=>validateCorrespondence(tetra,reverse),/consistently oriented/);
const otherTopology={vertices:tetra.vertices,faces:new Uint32Array([0,1,3,0,3,2,0,2,1,1,2,3])};
assert.throws(()=>validateCorrespondence(tetra,otherTopology),/same indexed triangle topology/);
const openSoup=new Float32Array([0,0,0, 1,0,0, 0,1,0]);
assert.throws(()=>weldTriangleSoup(openSoup),/xyz vertices|closed/);

// Genus-one fixture: the central tunnel is outside despite being in the bbox.
function torus() {
  const vertices=[],faces=[],n=20,m=14;
  for(let i=0;i<n;i++) for(let j=0;j<m;j++) {
    const a=2*Math.PI*i/n,b=2*Math.PI*j/m,r=3+Math.cos(b);
    vertices.push(r*Math.cos(a),r*Math.sin(a),Math.sin(b));
  }
  for(let i=0;i<n;i++) for(let j=0;j<m;j++) {
    const a=i*m+j,b=((i+1)%n)*m+j,c=((i+1)%n)*m+(j+1)%m,d=i*m+(j+1)%m;
    faces.push(a,b,c,a,c,d);
  }
  return {vertices:new Float64Array(vertices),faces:new Uint32Array(faces)};
}
const ring=torus();
assert.equal(containsPoint(ring,[0,0,0]),false,'tunnel is exterior');
assert.throws(()=>meanValueWeights(ring,[0,0,0]),/outside/);
verifyPoint(ring,[3,.1,.2],'genus-one interior');
assert.ok(negativeQueries>0,'nonconvex MVC must retain negative weights');
// Reversing all orientations must preserve the normalized result.
const inverted={vertices:ring.vertices,faces:ring.faces.slice()};
for(let f=0;f<inverted.faces.length;f+=3) [inverted.faces[f+1],inverted.faces[f+2]]=[inverted.faces[f+2],inverted.faces[f+1]];
assert.ok(distance(mapWeights(meanValueWeights(inverted,[3,.1,.2]),inverted),[3,.1,.2])<1e-10);

function readSTL(file) {
  const data=fs.readFileSync(file),count=data.readUInt32LE(80);
  assert.equal(data.length,84+50*count,'binary STL length');
  const positions=new Float32Array(count*9);
  for(let face=0;face<count;face++) for(let corner=0;corner<3;corner++) for(let axis=0;axis<3;axis++) {
    positions[9*face+3*corner+axis]=data.readFloatLE(84+50*face+12+12*corner+4*axis);
  }
  return weldTriangleSoup(positions);
}
const {template:templateEntry,cases}=JSON.parse(fs.readFileSync(new URL('./data/cases.json',import.meta.url))),templates=[];
assert.equal(templateEntry?.id,'case-000','A real source template must be declared separately from patient cases');
assert.equal(templateEntry.role,'template');
assert.equal(templateEntry.base,'web/templates/ssm/');
assert.equal(cases.length,5,'Expected five complete reconstructed cases');
assert.ok(cases.every(entry=>entry.role==='reconstruction'),'Patient entries must be reconstruction cases');
assert.equal(new Set(cases.map(entry=>entry.id)).size,5,'Patient case IDs must be unique');
assert.ok(cases.every(entry=>entry.id!==templateEntry.id),'The template must not replace a patient case');
const caseBase=entry=>new URL('../'+entry.base,import.meta.url);
for(let level=1;level<=5;level++) templates.push(readSTL(new URL(`recons/L${level}.stl`,caseBase(templateEntry))));
let surfaces=0,boundaries=0,topologies=0,templateSurfaces=0;
const templateStatistics={queries:0,identity:0,affine:0,partition:0},templateLevels=[];
function verifyBoundary(mesh,target,label) {
  // Check MVC's exact boundary branch on this mesh and homologous transfer in
  // both directions. A renderer's stored triangle index and corner order must
  // survive STL welding; a nearest-point match would not establish this.
  for(const f of [0,137,3999]) {
    const bary=[.21,.32,.47],weights=surfaceWeights(mesh,f,bary),point=mapWeights(weights,mesh),evaluated=meanValueWeights(mesh,point);
    const error=distance(mapWeights(evaluated,mesh),point);maxBoundary=Math.max(maxBoundary,error);boundaries++;
    assert.ok(error<1e-9,label+' exact boundary identity');
    for(let i=0;i<weights.length;i++) assert.ok(Math.abs(weights[i]-evaluated[i])<1e-8,label+' exact triangle boundary weights');
    const mapped=mapWeights(weights,target),expected=[0,0,0];
    for(let k=0;k<3;k++) xyz(target,target.faces[3*f+k]).forEach((v,axis)=>expected[axis]+=bary[k]*v);
    assert.ok(distance(mapped,expected)<1e-9,label+' homologous triangle map');
    const sourceWeights=surfaceWeights(target,f,bary);
    assert.ok(distance(mapWeights(sourceWeights,mesh),point)<1e-9,label+' source-to-target homologous triangle map');
    const vertexIndex=mesh.faces[3*f],vertexWeights=meanValueWeights(mesh,xyz(mesh,vertexIndex));
    assert.equal(vertexWeights[vertexIndex],1,label+' exact vertex weights');
    assert.equal(vertexWeights.filter(v=>v!==0).length,1);
  }
}
function verifyInterior(mesh,label,statistics=null) {
  // Offset into real bone triangles. Reject candidates entering the spinal
  // canal or crossing a nearby nonconvex boundary; never snap them inside.
  let accepted=0;
  for(let attempt=0;attempt<100&&accepted<4;attempt++) {
    const f=(attempt*271+137)%4000,a=xyz(mesh,mesh.faces[3*f]),b=xyz(mesh,mesh.faces[3*f+1]),c=xyz(mesh,mesh.faces[3*f+2]);
    const normal=cross(subtract(b,a),subtract(c,a)),normalLength=norm(normal);
    const depth=[.2,.6,1.1,1.7][accepted],point=a.map((v,i)=>(v+b[i]+c[i])/3-normal[i]/normalLength*depth);
    if(containsPoint(mesh,point)) {verifyPoint(mesh,point,label+` interior ${accepted}`,statistics);accepted++;}
  }
  assert.equal(accepted,4,label+' requires four interior test points');
}
for(let level=1;level<=5;level++) {
  const mesh=templates[level-1],label=`${templateEntry.id}/L${level}`;
  assert.equal(mesh.vertices.length/3,2000,label+' expected vertex count');
  assert.equal(mesh.faces.length/3,4000,label+' expected face count');
  assert.equal(validateCorrespondence(mesh,mesh),true);
  const statistics={queries:0,identity:0,affine:0,partition:0};
  verifyBoundary(mesh,mesh,label);
  verifyInterior(mesh,label,statistics);
  templateLevels.push({level,...statistics});
  templateStatistics.queries+=statistics.queries;
  for(const metric of ['identity','affine','partition']) templateStatistics[metric]=Math.max(templateStatistics[metric],statistics[metric]);
  templateSurfaces++;
}
for(const entry of cases) for(let level=1;level<=5;level++) {
  const mesh=readSTL(new URL(`recons/L${level}.stl`,caseBase(entry))),label=`${entry.id}/L${level}`;
  assert.equal(mesh.vertices.length/3,2000,label+' expected vertex count');
  assert.equal(mesh.faces.length/3,4000,label+' expected face count');
  assert.equal(validateCorrespondence(templates[level-1],mesh),true);topologies++;
  verifyBoundary(mesh,templates[level-1],label);
  verifyInterior(mesh,label);surfaces++;
}
assert.equal(topologies,25,'Every patient level must match the true source topology');
assert.equal(templateStatistics.queries,20,'Each true source level needs at least four interior identity/affine samples');
// CT references may themselves contain nonmanifold or open details. Either
// those fail mesh validation, or their independent topology fails matching.
assert.throws(()=>{
  const gt=readSTL(new URL('gt/L1.stl',caseBase(cases[0])));
  validateCorrespondence(templates[0],gt);
},/same indexed triangle topology|closed, consistently oriented|degenerate triangle|invalid triangle/,'independent GT must not be used as homologous geometry');
timings.sort((a,b)=>a-b);
console.log(`PASS: ${templateSurfaces} true source surfaces and ${surfaces} reconstructed surfaces (${cases.length} cases x 5 levels), ${topologies} template-topology checks, ${boundaries} boundary checks, ${queries} interior identity/affine queries.`);
console.log(`Maximum error: identity ${maxIdentity.toExponential(3)} mm; affine ${maxAffine.toExponential(3)} mm; boundary ${maxBoundary.toExponential(3)} mm; partition ${maxPartition.toExponential(3)}.`);
console.log(`True source only (${templateStatistics.queries} interior queries): identity ${templateStatistics.identity.toExponential(3)} mm; affine ${templateStatistics.affine.toExponential(3)} mm; partition ${templateStatistics.partition.toExponential(3)}.`);
for(const statistics of templateLevels) console.log(`True source L${statistics.level}: ${statistics.queries} interior samples; identity ${statistics.identity.toExponential(3)} mm; affine ${statistics.affine.toExponential(3)} mm.`);
console.log(`MVC latency: median ${timings[Math.floor(timings.length*.5)].toFixed(2)} ms; p95 ${timings[Math.floor(timings.length*.95)].toFixed(2)} ms; max ${timings.at(-1).toFixed(2)} ms. Signed negative weights retained in ${negativeQueries} queries.`);

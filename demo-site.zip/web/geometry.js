// Same corner convention as template_nlf/models/cone_beam_geometry.py:
// top-left, bottom-left, bottom-right, top-right; pixel origin at top-left.
export const sub = (a,b) => a.map((v,i)=>v-b[i]);
export const dot = (a,b) => a.reduce((s,v,i)=>s+v*b[i],0);
export const norm = a => Math.hypot(...a);
export const unit = a => a.map(v=>v/norm(a));
const cross = (a,b) => [a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]];
export function detectorPlaneData(calibration) {
  return {positions:calibration.plane.flat(),uvs:[1,1,1,0,0,0,0,1],indices:[0,1,2,0,2,3]};
}
export function basis({plane,source}) {
  const [tl,bl,br,tr] = plane;
  const right = unit(sub(tr,tl).map((v,i)=>(v+br[i]-bl[i])/2));
  const down = unit(sub(bl,tl).map((v,i)=>(v+br[i]-tr[i])/2));
  let forward = unit(cross(right,down));
  if(dot(forward,sub(tl,source))<0) forward=forward.map(v=>-v);
  return {tl,right,down,forward,width:norm(sub(tr,tl)),height:norm(sub(bl,tl))};
}
export function projectPixel(point,calibration,size=512) {
  const {tl,right,down,forward,width,height}=basis(calibration);
  const q=sub(point,calibration.source), origin=sub(tl,calibration.source);
  const distance=dot(forward,origin)/dot(forward,q);
  const local=q.map((v,i)=>v*distance-origin[i]);
  return [size*dot(local,right)/width,size*dot(local,down)/height];
}
// Row-major projection matrix. The camera translates to the source, without a
// rotation. Keeping detector axes in this matrix also preserves image handedness.
// An ordinary centered lookAt/FOV camera would lose off-axis detector offsets.
export function calibratedProjection(calibration,near=1,far=10000,flipX=false) {
  const {tl,right,down,forward,width,height}=basis(calibration);
  const origin=sub(tl,calibration.source), d=dot(forward,origin);
  const x=right.map((v,i)=>2*d/width*v-(2*dot(right,origin)/width+1)*forward[i]);
  const y=down.map((v,i)=>-2*d/height*v+(2*dot(down,origin)/height+1)*forward[i]);
  return [...x.map(v=>flipX?-v:v),0,...y,0,...forward.map(v=>v*(far+near)/(far-near)),-2*far*near/(far-near),...forward,0];
}
